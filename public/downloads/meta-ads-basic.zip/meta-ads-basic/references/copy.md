# Ad copy and hooks

## Text length (Meta's recommendations, not hard limits)
- Primary text: the first ~125 characters show before "See more". Put the point there.
- Headline: ~40 characters or less reads in full on most placements.
- Description: ~30 characters, often hidden. Do not put anything important there.

## 5 angles, one hook each
| Angle | Formula | Contoh (BM santai) |
|---|---|---|
| Pain | Name the exact problem in their words | "Customer tanya harga, lepas tu senyap?" |
| Result | Show the after state, no fake numbers | "Order masuk WhatsApp siap dengan nama dan alamat" |
| Curiosity | Hint at a method, deliver it in the body | "Satu ayat yang buat customer terus tekan Tempah" |
| Proof | Real review, real photo, real count | "Review customer minggu lepas, kami tak edit" |
| Offer | Clear offer + reason + deadline if real | "Free delivery Shah Alam sampai Ahad nie" |

## Full ad structure
1. Hook (line 1, the angle)
2. Who it is for (1 line, so the right person stops)
3. What they get (2-3 short lines or bullets)
4. Proof or reason to trust (1 line)
5. Clear next step that matches the button ("Tekan WhatsApp, tanya stok")

## Creative first 3 seconds
- Show the product or result in frame 1, not a logo.
- Text on screen = the hook, big, inside the middle of the frame (safe area for Reels and Stories).
- Real phone footage often beats polished stock for SMEs. Faces, hands, the shop, the process.
- Make 4:5 for feed and 9:16 for Reels/Stories.

## Bahasa
- Write the way the customer talks. BM rojak is fine for most Klang Valley audiences.
- One idea per ad. If you need "dan" three times, split into two ads.
- Avoid words that call out personal attributes ("Anda gemuk?", "Hutang banyak?"). Meta's policy restricts ads that assert or imply personal characteristics. Say "Nak mula diet yang senang ikut?" instead.
