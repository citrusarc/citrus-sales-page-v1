# Baca result ads

## Metrics in plain language
- Spend: duit yang dah keluar.
- Results / Cost per result: berapa kali jadi benda yang kita nak, dan kos setiap satu. This is the number that matters most.
- CPM: kos utk 1,000 kali ads keluar. High CPM = audience mahal or creative low quality ranking.
- CTR (link): % orang yang nampak dan tekan link. Low = creative or hook tak cukup kuat.
- Frequency: purata berapa kali seorang nampak ads. Rising frequency with rising cost = orang dah jemu.
- Conversion rate (results / link clicks): low with good CTR = masalah kat landing page, harga or offer, not the ad.

## Rules of thumb (compare with your own account first, these are not Meta benchmarks)
- CTR link under about 1% on cold audiences often means a weak hook.
- Frequency above about 3 in 7 days plus cost per result going up = refresh creative.
- Good CTR but few results = check landing page, price, offer, form length, WhatsApp reply speed.

## Decision tree
1. Spend too low to judge (under ~2x target cost per result, or under 3 days)? -> Tunggu.
2. CPM very high vs last month or vs other ad sets? -> Audience too narrow, or creative rated low. Try broader audience or new creative.
3. CTR low? -> Hook/creative problem. New first 3 seconds, new angle.
4. CTR OK, results low? -> Landing page, offer, or follow-up problem (e.g. WhatsApp replied after 3 hours).
5. Results OK but getting more expensive, frequency rising? -> Creative fatigue. Add new creatives, keep the winner running.
6. Everything OK? -> Scale slowly. Raise budget in steps (people often use about 20% every few days) instead of doubling overnight, so delivery stays stable.

## What to ask for if data is missing
"Boleh screenshot Ads Manager level ad, dengan column Amount spent, Results, Cost per result, Impressions, Link clicks, CTR (link), CPM, Frequency? Pilih tarikh 7 hari terakhir."
