# Pilih objective

Meta optimises delivery for the result you pick. Match the objective to what the customer should do next.

| Customer patut buat apa | Objective | Conversion location | Metric utama |
|---|---|---|---|
| WhatsApp kedai | Engagement (or Sales if Pixel/CAPI tracks purchases) | Messaging apps: WhatsApp | Cost per messaging conversation started |
| Isi borang (property, kelas, servis) | Leads | Instant form, or website if Pixel tracks leads | Cost per lead, then % yang jadi customer |
| Beli online | Sales | Website (needs Pixel, ideally Conversions API) | Cost per purchase, ROAS |
| Datang kedai fizikal | Awareness or Traffic, local radius | Website or Maps page | Reach in radius, cost per 1,000 reached, walk-ins you count yourself |
| Tengok video, kenal brand | Awareness or Engagement (video views) | On ad | ThruPlay cost, hook rate |
| Follow page / profile | Engagement | Page or profile | Cost per follow |

## Boost post vs Ads Manager
- Boost: quick, few settings. Good for pushing a post that already gets organic engagement, or simple messaging goals.
- Ads Manager: full control of objective, placements, schedule, A/B tests, multiple creatives, Pixel events. Use it once money matters.

## Pixel and Conversions API (simple version)
- Pixel = code on the website that tells Meta who bought or filled a form.
- Conversions API (CAPI) = the same signal sent from the server, which survives browser blocking. Use both, with the same event ID so Meta does not double count.
- No website? Click-to-WhatsApp or Instant Form works without a Pixel. Track sales yourself in a simple sheet.

## Budget starting point
- Learning phase: Meta says an ad set usually needs about 50 optimisation events in 7 days to exit learning. If the budget cannot get near that, pick an event higher in the funnel (e.g. conversation started instead of purchase), or accept slower learning.
- Rough check: daily budget x 7 / your target cost per result = expected results per week.
