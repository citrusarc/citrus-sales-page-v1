# Full account audit

## Export to ask for
Ads Manager > Reports (or the campaign table) > Breakdown none (or Day for anomalies) > columns:
Campaign name, Ad set name, Ad name, Delivery, Amount spent, Impressions, Reach, Frequency, CPM, Link clicks, CTR (link click-through rate), CPC (cost per link click), Results, Result indicator, Cost per result, Purchase ROAS (if e-commerce), 3-second video plays, ThruPlays, Video plays at 25/50/75/95%, Website URL (or URL parameters).
Date range: last 30 days for audit, last 7-14 days for creative decisions. Export as CSV.

## Score (start at 100)
Run `scripts/ads_report.py` first; it prints most of these flags. Then score:

### Critical (-10 each)
- Objective does not match the business goal (e.g. Traffic for an e-commerce store that tracks purchases).
- Purchase or lead optimisation with no working Pixel/CAPI signal (results 0 while link clicks are high, or user confirms events are missing in Events Manager).
- Ad sets with spend over 3x target cost per result and zero results.
- One ad set or ad taking most of the budget while others get almost none for a week or more, and the starved ones are the ones being "tested".

### High (-5 each)
- Frequency above ~3.5 in 7 days on a cold audience with cost per result rising.
- Link CTR well below the account's median, on ads with meaningful spend.
- CPM more than 2x the account median for the same objective.
- Only 1-2 active creatives per ad set or campaign (nothing to learn from, nothing to rotate).
- Same creatives running 30+ days with cost per result rising.
- Video hook rate under ~20% on ads that are the main spenders.

### Medium (-2 each)
- Names do not follow a convention, so you cannot group by angle or format.
- No UTM parameters on website ads.
- Several ad sets targeting the same or overlapping audience in one account, competing with each other.
- Many tiny ad sets that each cannot reach ~50 results a week (learning limited). Consolidate.
- Lead form with no qualifying question and no follow-up process.

## Wasted spend
Report in RM: spend on ad sets/ads with 0 results past 3x target CPR, spend on fatigued ads (frequency rule above), and spend on placements/audiences that are clearly worse after enough data. Remember Meta's "breakdown effect": the system shifts budget to cheaper results over time, so a breakdown that looks expensive on average may still be adding cheap marginal results. Do not cut a placement only on its average cost per result; test it.

## Output
1. Score /100 and the 1-line verdict.
2. Wasted spend in RM, with the rows that cause it.
3. Top 5 actions, ranked by impact over effort.
4. Budget shift proposal (from -> to, RM per day), only between things with enough data.

<a id="anomalies"></a>
## Anomalies (day breakdown)
`scripts/ads_report.py --daily file.csv` compares the last day to the previous 7 for each campaign: CPM, CTR, CPC, cost per result, frequency and spend, with a z-score. |z| >= 2 = warning, >= 3 = critical. Likely causes to check, in order:
- Cost up, CTR down, frequency up -> creative fatigue.
- CPM up across all campaigns at once -> auction season (e.g. 11.11, 12.12, Raya, year-end sales). Not your fault; protect budget or ride it.
- Results to 0 while clicks normal -> Pixel/CAPI, form or WhatsApp number broken. Check Events Manager and test the funnel yourself.
- Spend to 0 -> payment method, ad rejected, account restricted, budget ended.
