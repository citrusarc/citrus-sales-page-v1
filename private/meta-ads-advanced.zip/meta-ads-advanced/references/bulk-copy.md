# Bulk copy matrix

Use when the user wants many variants for testing.

## Inputs (ask once)
Product, audience, main benefit, 3 secondary benefits, real proof available, offer and deadline (if real), top 3 objections, language (BM / EN / rojak), destination (WhatsApp / form / website).

## Matrix
Rows = 6 angles: pain, result, curiosity, proof, offer, objection-buster.
Columns = 2 frameworks:
- PAS: Problem -> Agitate (gently, no fear-mongering) -> Solution
- AIDA: Attention -> Interest -> Desire -> Action
For each cell, write 3 variants. That is 36 ads. Add 6 short "story" ads (founder or customer moment, 3-4 lines) if the user asks for more.

## Format each variant as
```
[angle]-[framework]-[n]
H: headline
P: primary text (point in the first 125 characters)
CTA: button
Creative: frame 1 + on-screen line
```
Then run `python3 scripts/copy_check.py file.txt` (or count by hand) and fix anything over ~40 characters for H or where the point sits after character 125 in P.

## Quality bar
- Each variant must differ in the idea, not only in words.
- Customer language from comments, reviews, WhatsApp chats beats marketer language. Ask the user to paste 5-10 real customer messages if they can.
- Run every variant through `references/compliance-my.md` if the category is regulated.
