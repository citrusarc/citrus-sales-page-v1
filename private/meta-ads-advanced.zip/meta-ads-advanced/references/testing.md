# Testing and scaling

## Simple structure for SMEs (budget under ~RM100/day)
- 1 campaign, 1 broad ad set (location + age if needed, Advantage+ audience on), 3-6 ads.
- Let Meta distribute between ads. Judge ads after each has spent ~1-2x target cost per result, or after 4-7 days.
- Add new ads into the same ad set rather than creating new ad sets each time, so learning is not split.

## Larger budgets
- Testing campaign: new creatives, equal budget per ad set (ABO) or Meta's A/B test tool, one variable at a time.
- Scaling campaign: proven winners, campaign budget (Advantage+ campaign budget) or Advantage+ sales/leads campaign.
- Move winners from testing into scaling by duplicating the ad (or using the same post ID to keep social proof).

## One variable at a time
Test in this order, biggest impact first: offer -> angle -> hook (first 3 seconds) -> format -> copy length -> audience.

## Kill / keep / scale rules (state them to the user before the test starts)
- Kill: spend over 2-3x target CPR with 0 results, or CPR over ~1.5x target after enough results.
- Keep: CPR near target, give it more time.
- Scale: CPR under target for 3+ days with stable frequency. Raise budget in steps (about 20% every 2-3 days is a common rule) or duplicate into the scaling campaign. Big jumps or edits can restart learning.

## Learning phase
Meta says an ad set usually needs about 50 optimisation events within 7 days after the last significant edit to exit learning. Significant edits include big budget changes, targeting changes, new creative added to the ad set, optimisation event changes and pausing for a long time. Batch your edits.

## Seasonality in Malaysia
CPMs usually rise around big sale dates (11.11, 12.12, Black Friday, year-end), Ramadan and Raya. Plan creative and budget for these periods, and do not judge a test that straddles them against normal weeks.

## Test plan output
| Test | Variable | Ads | Budget/day | Run until | Decision rule |
