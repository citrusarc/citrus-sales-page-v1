# Competitor research (Meta Ad Library)

The Ad Library (facebook.com/ads/library) is public and needs no login to browse active ads.

## Method
1. User gives 3-5 competitor Pages (or you search by keyword with Country = Malaysia).
2. For each, note: number of active ads, how long the oldest active ad has been running, formats, main angle, offer, CTA, landing destination (WhatsApp, website, form).
3. Ads that have run a long time are likely profitable for them. Many variants of one idea = they are testing it or scaling it.
4. Read at human pace. Do not scrape, bulk download or automate the site. If the user wants automation, the official Ad Library API exists; they set it up with their own token.

## Output
| Competitor | Active ads | Longest running | Main angle | Offer | Destination |
Then:
- Patterns across competitors (what everyone says).
- Gaps (angles, proof or offers nobody uses) = your opportunity.
- 3 briefs that are different, not copies. Never copy a competitor's creative or text.
