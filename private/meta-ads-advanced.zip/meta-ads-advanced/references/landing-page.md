# Landing page for ads

Use when CTR is fine but results are low, or before scaling.

## 10-point check (score /10)
1. Loads fast on mobile data (ask user to test; if they can, run PageSpeed Insights and quote the mobile result).
2. Headline repeats the ad's promise (message match).
3. Says what it is, for whom, and what to do next within the first screen.
4. One primary button above the fold; same action repeated down the page.
5. Price or price range visible (or a clear reason why not).
6. Real proof: reviews, photos, client names with permission, numbers they can back.
7. Objections answered (delivery area, payment, warranty, halal, timeline).
8. Form asks only what is needed; WhatsApp button pre-fills a message.
9. Readable on phone: body text ~16px, enough contrast, no popup on load.
10. Tracking works: Pixel/CAPI events fire on the thank-you page or WhatsApp click; UTMs present.

## Output
Score, the top 3 fixes in order, and a rewritten first screen (headline, sub-line, button text) that matches the best ad.
