# Click-to-WhatsApp funnel

The most used ad flow for Malaysian SMEs. Meta reports conversations started. It does not know who bought unless you track it.

## Setup checklist
- Objective: Engagement or Sales with conversion location Messaging apps > WhatsApp (Leads also offers messaging). Link the WhatsApp Business number to the Page.
- Greeting / ice-breaker questions set in the ad's message template (e.g. "Nak tanya harga", "Nak tengok katalog", "Nak tempah slot").
- WhatsApp Business: away message, quick replies, labels (Baru, Tanya harga, Hot, Beli, Tak jadi), catalogue.
- One person owns replies during ad hours. Speed matters; leads cool down fast.

## Track the real number
Use `templates/sales-tracker.csv`. Each day log: ad (from the ad name in the first message or the ice-breaker used), conversations, qualified (asked price or gave details), sales, revenue.
Then:
- Cost per conversation = spend / conversations (Meta shows this)
- Cost per qualified lead = spend / qualified
- Cost per sale = spend / sales
- ROAS = revenue / spend
Judge ads on cost per sale where possible, not cost per conversation. A cheap ad that brings "hi" messages and no buyers is expensive.

## Reply script (BM, adapt)
1. Within 5 min: "Hi! Terima kasih tanya 😊 Nak saya bantu pasal [produk] ya? Boleh saya tahu nak guna utk apa?"
2. Qualify: 1-2 questions (lokasi, bila perlu, budget).
3. Answer with price + 1 proof (gambar sebenar / review) + next step.
4. Follow up once next day if silent, once 3 days later with something new (stok terhad, testimoni). Then stop.
Respect the person: no spam broadcasts to people who did not opt in.

## When conversations are cheap but sales are low
- Ad promises too much or is vague -> curious clickers. Make price range or who-it-is-for clear in the ad.
- Reply too slow or too pushy.
- Offer/price mismatch with the audience. Fix before spending more.
