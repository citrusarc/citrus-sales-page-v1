# Creative analysis

## Tag every ad
From the ad name (see `templates/naming.md`) or by asking:
- Angle: pain, result, curiosity, proof (testimoni/review), offer, demo, before-after, education, founder-story, ugc.
- Format: image, video-short (<15s), video-long, carousel, reel-ugc.
- Hook number (h1, h2...) when the same video is tested with different openings.

`scripts/ads_report.py` groups by the first two parts of the ad name (angle, format) when names follow the convention.

## Metrics
- Hook rate = 3-second video plays / impressions. Did the first 3 seconds stop the scroll?
- Hold rate = ThruPlays / 3-second video plays. Did people stay?
- Link CTR, cost per result, conversion rate (results / link clicks).
These video ratios are industry metrics, not Meta-reported columns. Rules of thumb people use: hook above ~25-30% is strong, under ~15-20% is weak. Compare with the account first.

## Read the pattern
- Hook weak, hold fine -> keep the body, test 3 new openings (first frame, first line on screen).
- Hook strong, hold weak -> the opening promises something the video does not deliver quickly. Cut the intro, show the product by second 3-5.
- CTR good, conversion weak -> not a creative problem. Landing page, offer, price, form, or WhatsApp reply.
- Ranking: only rank ads with spend above ~1-2x target cost per result. Small-spend ads are noise.

## Next creative brief (always end with this)
For the top 2 angle+format combinations:
"Data: [angle + format] cost per result RM[x] vs account RM[y] (n ads, RM spend).
Brief: [what frame 1 shows], [on-screen hook line], [proof shown], [CTA], length [s], 4:5 + 9:16.
Make: 3 variations changing only the hook."
Plus 1 wildcard angle not tested yet.
