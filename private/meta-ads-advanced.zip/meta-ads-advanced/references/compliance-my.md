# Malaysia ad compliance check

Not legal advice. Flag the risk, name the authority, and tell the user to confirm with them for anything regulated.

## Ask: what is being advertised?

### Medicines, traditional products, supplements with health claims
- Ads for medicines and health remedies need approval from the Medicine Advertisements Board (Lembaga Iklan Ubat, KKM) under the Medicines (Advertisement and Sale) Act 1956. Approved ads carry a KKLIU approval number. Ask the user for it.
- No claims to cure or prevent diseases the Act lists. No "100% berkesan", "lulus KKM" unless it is true and exactly worded.
- Products must also be registered where required (e.g. NPRA registration numbers MAL...). Ask.

### Beauty, slimming, cosmetics
- Cosmetics must be notified with NPRA (notification number). Do not make medical claims for cosmetics.
- Meta policy: no before/after images implying unrealistic results for weight loss, no body-shaming, no personal attribute call-outs ("Anda gemuk?"). Ads for weight loss products are age-restricted.

### Halal
- Only say "halal" or use a halal logo if the product holds a valid JAKIM (or state/recognised) halal certificate. Misuse can be an offence under the Trade Descriptions Act 2011 and its halal orders. Ask for the certificate.

### Pricing, promos and claims
- Consumer Protection Act 1999 and Trade Descriptions Act 2011: no misleading prices, fake "was RM" prices, fake scarcity or fake reviews. Testimonials must be real and with permission.

### Lead forms and customer data
- PDPA 2010: say what data you collect and why, and link a privacy notice in the Instant Form. Do not reuse leads for unrelated marketing without consent.

### Special Ad Categories (Meta)
Financial products and services (loans, credit cards, insurance, investment), employment, housing/property, and social issues, elections or politics must be declared as a Special Ad Category. Targeting options are restricted. Investment and crypto ads have extra rules. Political/social issue ads need authorisation and a "Paid for by" disclaimer.

### Other Meta restrictions to check
Alcohol (age and country rules), gambling (authorisation), dating, prescription drugs, weapons, adult content, tobacco and vapes (prohibited).

## Output
| Item | Risk | What to check | Who confirms |
Then the safest version of the ad copy.
