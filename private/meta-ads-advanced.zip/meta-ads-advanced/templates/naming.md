# Naming convention

Consistent names let `scripts/ads_report.py` group results by angle and format.

- Campaign: `[objective]-[product]-[market]-[YYMM]` e.g. `wa-kek-lapis-shahalam-2612`
- Ad set: `[audience]-[placement or auto]-[YYMMDD]` e.g. `broad-25-44-auto-261201`
- Ad: `[angle]-[format]-[hook]-[YYMMDD]` e.g. `proof-video-h2-261203`

Angles: pain, result, curiosity, proof, offer, demo, beforeafter, education, founder, ugc, objection
Formats: image, video, reel, carousel

Use only `-` between parts and no spaces inside a part.
