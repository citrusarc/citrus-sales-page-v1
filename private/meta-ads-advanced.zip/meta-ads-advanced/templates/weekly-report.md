# Weekly report template

Fill only with real numbers from the export or the sales tracker. Keep it to one screen.

```
Laporan Ads [Brand], [tarikh mula] - [tarikh akhir]

Ringkasan: [1 ayat: naik/turun, kenapa]

| | Minggu nie | Minggu lepas | Beza |
|---|---|---|---|
| Spend (RM) | | | |
| Result ([jenis]) | | | |
| Kos setiap result (RM) | | | |
| Jualan / Revenue (RM) | | | |  <- dari sales tracker, jika ada
| ROAS | | | |

Yang menang: [ad name] - [kenapa, 1 baris]
Yang kalah: [ad name] - [tindakan: pause / tukar hook]

Minggu depan:
1. [tindakan]
2. [tindakan]
3. [tindakan]

Nota: [season, stok, perubahan website, apa2 yang jejaskan nombor]
```
English version: same structure, translated headings.
