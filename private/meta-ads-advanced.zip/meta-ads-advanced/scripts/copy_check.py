#!/usr/bin/env python3
"""Check ad copy length (part of the Meta Ads Advanced skill).

Usage: python3 copy_check.py copy.txt
Lines starting with H: (headline), P: (primary text) or D: (description)
are counted. Headline over 40, description over 30, or primary text
longer than 125 characters on its first line are flagged.
"""
import sys

LIMITS = {"H": 40, "D": 30, "P": 125}


def main(path):
    bad = 0
    with open(path, encoding="utf-8") as f:
        for n, line in enumerate(f, 1):
            s = line.rstrip("\n")
            tag = s[:2]
            if tag not in ("H:", "P:", "D:"):
                continue
            text = s[2:].strip()
            limit = LIMITS[tag[0]]
            size = len(text)
            mark = "OK" if size <= limit else "OVER"
            if mark == "OVER":
                bad += 1
            note = " (point must be before here)" if tag == "P:" and size > limit else ""
            print(f"line {n} {tag} {size}/{limit} {mark}{note}: {text[:60]}")
    print(f"\n{bad} line(s) over the recommended length")


if __name__ == "__main__":
    if len(sys.argv) != 2:
        sys.exit(__doc__)
    main(sys.argv[1])
