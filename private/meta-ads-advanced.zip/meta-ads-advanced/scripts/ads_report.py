#!/usr/bin/env python3
"""Meta Ads Manager CSV report (part of the Meta Ads Advanced skill).

Usage:
  python3 ads_report.py export.csv [--target-cpr 25] [--currency RM]
  python3 ads_report.py export_by_day.csv --daily

Reads a CSV exported from Ads Manager, works out derived metrics
(CTR, CPM, CPC, cost per result, hook rate, hold rate), flags problems,
groups ads by angle and format from the ad name, and with --daily compares
the last day with the 7 days before it. Standard library only.
"""
import argparse
import csv
import statistics
import sys
from collections import OrderedDict, defaultdict

COLS = {
    "campaign": ["campaign name"],
    "adset": ["ad set name"],
    "ad": ["ad name"],
    "day": ["day", "reporting starts", "date"],
    "spend": ["amount spent"],
    "impr": ["impressions"],
    "reach": ["reach"],
    "freq": ["frequency"],
    "clicks": ["link clicks"],
    "results": ["results"],
    "v3": ["3-second video plays", "3-second video views", "video plays 3s"],
    "thru": ["thruplays", "thruplay"],
    "roas": ["purchase roas", "website purchase roas"],
    "value": ["purchases conversion value", "website purchases conversion value"],
}
NUMERIC = ["spend", "impr", "reach", "freq", "clicks", "results", "v3", "thru", "roas", "value"]


def find_columns(header):
    norm = [h.strip().lower().lstrip("﻿") for h in header]
    found = {}
    for key, names in COLS.items():
        for name in names:
            # exact match first, then "starts with" (e.g. "Amount spent (MYR)")
            for i, h in enumerate(norm):
                if h == name:
                    found[key] = i
                    break
            if key in found:
                break
            for i, h in enumerate(norm):
                if h.startswith(name) and not (key == "results" and h.startswith("results ")):
                    found[key] = i
                    break
            if key in found:
                break
    return found


def num(v):
    if v is None:
        return 0.0
    v = str(v).strip().replace(",", "").replace("RM", "").replace("%", "")
    if v in ("", "-", "--"):
        return 0.0
    try:
        return float(v)
    except ValueError:
        return 0.0


def load(path):
    with open(path, newline="", encoding="utf-8-sig") as f:
        rows = list(csv.reader(f))
    if not rows:
        sys.exit("Empty file")
    cols = find_columns(rows[0])
    data = []
    for r in rows[1:]:
        if not any(c.strip() for c in r):
            continue
        rec = {}
        for k, i in cols.items():
            val = r[i] if i < len(r) else ""
            rec[k] = num(val) if k in NUMERIC else val.strip()
        data.append(rec)
    return cols, data


def level(cols):
    for k in ("ad", "adset", "campaign"):
        if k in cols:
            return k
    sys.exit("No Campaign name, Ad set name or Ad name column found")


def agg(rows):
    out = defaultdict(float)
    for r in rows:
        for k in NUMERIC:
            if k in ("freq", "roas"):
                continue
            out[k] += r.get(k, 0.0)
    # frequency: impressions / reach when reach exists, else spend-weighted mean
    if out["reach"]:
        out["freq"] = out["impr"] / out["reach"]
    else:
        w = sum(r.get("spend", 0) for r in rows) or 1
        out["freq"] = sum(r.get("freq", 0) * r.get("spend", 0) for r in rows) / w
    if out["value"] and out["spend"]:
        out["roas"] = out["value"] / out["spend"]
    else:
        w = sum(r.get("spend", 0) for r in rows) or 1
        out["roas"] = sum(r.get("roas", 0) * r.get("spend", 0) for r in rows) / w
    return derive(out)


def derive(m):
    m = dict(m)
    impr, clicks, spend, res = m.get("impr", 0), m.get("clicks", 0), m.get("spend", 0), m.get("results", 0)
    m["ctr"] = clicks / impr * 100 if impr else None
    m["cpm"] = spend / impr * 1000 if impr else None
    m["cpc"] = spend / clicks if clicks else None
    m["cpr"] = spend / res if res else None
    m["cvr"] = res / clicks * 100 if clicks else None
    m["hook"] = m["v3"] / impr * 100 if m.get("v3") and impr else None
    m["hold"] = m["thru"] / m["v3"] * 100 if m.get("thru") and m.get("v3") else None
    return m


def fmt(v, kind="n", cur="RM"):
    if v is None:
        return "-"
    if kind == "money":
        return f"{cur}{v:,.2f}"
    if kind == "pct":
        return f"{v:.2f}%"
    if kind == "int":
        return f"{v:,.0f}"
    return f"{v:.2f}"


def median(vals):
    vals = [v for v in vals if v is not None]
    return statistics.median(vals) if vals else None


def report(path, target_cpr, cur):
    cols, data = load(path)
    lv = level(cols)
    groups = OrderedDict()
    for r in data:
        groups.setdefault(r.get(lv, "(no name)"), []).append(r)
    ents = {name: agg(rows) for name, rows in groups.items()}
    total = agg(data)
    med_ctr = median(e["ctr"] for e in ents.values() if e["spend"] > 0)
    med_cpm = median(e["cpm"] for e in ents.values() if e["spend"] > 0)
    ref_cpr = target_cpr or total["cpr"]

    print(f"# Ads report: {path}")
    print(f"Level: {lv} | rows: {len(data)} | entities: {len(ents)}")
    missing = [k for k in ("spend", "impr", "clicks", "results") if k not in cols]
    if missing:
        print(f"Missing columns: {', '.join(missing)} (some metrics will show '-')")
    print()
    print("## Totals")
    print(f"Spend {fmt(total['spend'], 'money', cur)} | Results {fmt(total['results'], 'int')} | "
          f"Cost per result {fmt(total['cpr'], 'money', cur)} | CTR link {fmt(total['ctr'], 'pct')} | "
          f"CPM {fmt(total['cpm'], 'money', cur)} | Frequency {fmt(total['freq'])}"
          + (f" | ROAS {total['roas']:.2f}" if total.get("roas") else ""))
    print(f"Medians across {lv}s: CTR {fmt(med_ctr, 'pct')}, CPM {fmt(med_cpm, 'money', cur)}. "
          f"Reference cost per result: {fmt(ref_cpr, 'money', cur)} "
          f"({'target' if target_cpr else 'account average'})")
    print()

    print(f"## By {lv} (sorted by spend)")
    print("| Name | Spend | Results | CPR | CTR link | CPM | Freq | Hook | Hold | Flags |")
    print("|---|---|---|---|---|---|---|---|---|---|")
    wasted = 0.0
    flagged = []
    for name, e in sorted(ents.items(), key=lambda x: -x[1]["spend"]):
        flags = []
        if ref_cpr and e["results"] == 0 and e["spend"] > 3 * ref_cpr:
            flags.append("ZERO-RESULTS")
            wasted += e["spend"]
        elif ref_cpr and e["cpr"] and e["cpr"] > 1.5 * ref_cpr and e["spend"] > 2 * ref_cpr:
            flags.append("CPR-HIGH")
        if e["freq"] and e["freq"] > 3.5:
            flags.append("FATIGUE?")
        if med_ctr and e["ctr"] is not None and e["spend"] > 0 and e["ctr"] < 0.5 * med_ctr:
            flags.append("CTR-LOW")
        if med_cpm and e["cpm"] and e["cpm"] > 2 * med_cpm:
            flags.append("CPM-HIGH")
        if e["hook"] is not None and e["hook"] < 20:
            flags.append("HOOK-WEAK")
        if e["ctr"] and med_ctr and e["ctr"] >= med_ctr and e["cvr"] is not None and e["clicks"] >= 30 and e["cvr"] < 1:
            flags.append("CLICKS-NO-CONVERT")
        if flags:
            flagged.append((name, flags))
        print(f"| {name} | {fmt(e['spend'], 'money', cur)} | {fmt(e['results'], 'int')} | {fmt(e['cpr'], 'money', cur)} | "
              f"{fmt(e['ctr'], 'pct')} | {fmt(e['cpm'], 'money', cur)} | {fmt(e['freq'])} | {fmt(e['hook'], 'pct')} | "
              f"{fmt(e['hold'], 'pct')} | {' '.join(flags)} |")
    print()
    share = wasted / total["spend"] * 100 if total["spend"] else 0
    print(f"## Wasted spend (zero results past 3x reference CPR): {fmt(wasted, 'money', cur)} ({share:.1f}% of spend)")
    print()

    if lv == "ad":
        combos = defaultdict(list)
        for name, rows in groups.items():
            parts = [p for p in name.lower().replace("_", "-").split("-") if p]
            if len(parts) >= 2:
                combos[(parts[0], parts[1])].extend(rows)
        if len(combos) >= 2:
            print("## By angle + format (from ad name: angle-format-hook-date)")
            print("| Angle | Format | Ads | Spend | Results | CPR | CTR link | Hook |")
            print("|---|---|---|---|---|---|---|---|")
            for (a, f), rows in sorted(combos.items(), key=lambda x: (agg(x[1])["cpr"] or 1e9)):
                m = agg(rows)
                n = len({r.get("ad") for r in rows})
                print(f"| {a} | {f} | {n} | {fmt(m['spend'], 'money', cur)} | {fmt(m['results'], 'int')} | "
                      f"{fmt(m['cpr'], 'money', cur)} | {fmt(m['ctr'], 'pct')} | {fmt(m['hook'], 'pct')} |")
            print("Note: rank only combinations with enough spend (about 1-2x target CPR or more).")
            print()

    print("## Flag key")
    print("ZERO-RESULTS spend > 3x reference CPR, no results | CPR-HIGH CPR > 1.5x reference | FATIGUE? frequency > 3.5 |")
    print("CTR-LOW under half the median | CPM-HIGH over 2x the median | HOOK-WEAK 3s plays / impressions < 20% |")
    print("CLICKS-NO-CONVERT CTR at or above median, 30+ clicks, conversion rate < 1% (check landing page, offer, follow-up)")
    print("Thresholds are rules of thumb. Compare with the account's own history before acting.")


def daily(path, cur):
    cols, data = load(path)
    if "day" not in cols:
        sys.exit("Need a Day column: export with Breakdown > By time > Day")
    key = "campaign" if "campaign" in cols else level(cols)
    by = defaultdict(lambda: defaultdict(list))
    for r in data:
        by[r.get(key, "(no name)")][r["day"]].append(r)
    print(f"# Anomaly check: {path} (last day vs previous 7, by {key})")
    print("| Name | Metric | Last day | 7-day mean | z | Level |")
    print("|---|---|---|---|---|---|")
    any_flag = False
    metrics = [("cpm", "money"), ("ctr", "pct"), ("cpc", "money"), ("cpr", "money"), ("freq", "n"), ("spend", "money")]
    for name, days in by.items():
        ordered = sorted(days)
        if len(ordered) < 4:
            continue
        last = agg(days[ordered[-1]])
        base = [agg(days[d]) for d in ordered[-8:-1]]
        for m, kind in metrics:
            vals = [b[m] for b in base if b.get(m) is not None]
            if len(vals) < 3 or last.get(m) is None:
                continue
            mean = statistics.mean(vals)
            sd = statistics.pstdev(vals)
            if sd == 0:
                continue
            z = (last[m] - mean) / sd
            if abs(z) >= 2:
                any_flag = True
                lvl = "CRITICAL" if abs(z) >= 3 else "warning"
                print(f"| {name} | {m} | {fmt(last[m], kind, cur)} | {fmt(mean, kind, cur)} | {z:+.1f} | {lvl} |")
        if last["spend"] > 0 and last["results"] == 0 and sum(b["results"] for b in base) > 0:
            any_flag = True
            print(f"| {name} | results | 0 | {statistics.mean(b['results'] for b in base):.1f} | - | CRITICAL (check Pixel/form/WhatsApp) |")
    if not any_flag:
        print("| (none) | | | | | no |z| >= 2 |")


def main():
    p = argparse.ArgumentParser()
    p.add_argument("csv")
    p.add_argument("--target-cpr", type=float, default=None, help="target cost per result")
    p.add_argument("--currency", default="RM")
    p.add_argument("--daily", action="store_true", help="anomaly check on a Day breakdown export")
    a = p.parse_args()
    if a.daily:
        daily(a.csv, a.currency)
    else:
        report(a.csv, a.target_cpr, a.currency)


if __name__ == "__main__":
    main()
