---
name: meta-ads-advanced
description: Use for any Facebook and Instagram (Meta) ads work for a Malaysian SME or client - full account audit from an Ads Manager CSV, creative performance by angle and format, hook and hold rate, anomaly and fatigue checks, testing and scaling plans, bulk ad copy in Malay and English, Click-to-WhatsApp funnels, Malaysian ad compliance (KKLIU, halal, PDPA), competitor research in Ad Library, and weekly client reports. Paid version; includes everything in Meta Ads Basic.
---

# Meta Ads Advanced

The paid version of Meta Ads Basic by Badrul Hanif (Citrus Arc Studio). It is everything in Basic plus the work an ads manager does each week. Not affiliated with Meta. Licence: see `LICENSE.txt`.

## Ground rules
- Talk in casual Bahasa Melayu by default (English ad terms are fine). Use English if the user writes in English or the report is for an English-speaking client.
- Only real numbers. Every figure you report comes from the user's data or a script output. Say "data tak cukup" rather than estimate.
- Rules of thumb in this skill are starting points. Always compare against the account's own history first, and say which one you used.
- Never promise results. Never publish, edit or pause ads yourself, and never ask for or store an access token in chat. If the user wants API automation, tell them to keep tokens in a local `.env` file they create.
- Not legal advice. For regulated products, point to the authority to confirm.

## Intake (once per account; save as `ACCOUNT.md` in the working folder if the user agrees)
Business and product, price range, main conversion (WhatsApp, lead, purchase, walk-in), target cost per result or ROAS, monthly budget in RM, market (state or radius), Pixel/CAPI status, past best ad, and the naming convention (see `templates/naming.md`).

## Modules
Pick the module from the user's request. Read its reference before answering.

| # | Module | When | Read |
|---|---|---|---|
| 1 | Setup and objective | New campaign, boost vs Ads Manager, wrong objective | `references/objectives.md` |
| 2 | Copy and hooks | Any ad copy | `references/copy.md` (Basic) + `references/bulk-copy.md` |
| 3 | Quick read | User pastes a few numbers or a screenshot | `references/read-results.md` |
| 4 | Full account audit | CSV export of campaigns, ad sets or ads | `references/audit.md` + run `scripts/ads_report.py` |
| 5 | Creative analysis | Which ads, angles or formats win; next brief | `references/creative.md` + `scripts/ads_report.py` |
| 6 | Anomaly and fatigue | "Kenapa tiba2 mahal", daily breakdown export | `references/audit.md#anomalies` + `scripts/ads_report.py --daily` |
| 7 | Testing and scaling | Plan tests, when to kill or scale, budget moves | `references/testing.md` |
| 8 | Click-to-WhatsApp funnel | Messaging ads, lead quality, reply scripts | `references/whatsapp.md` + `templates/sales-tracker.csv` |
| 9 | Malaysia compliance | Health, supplement, beauty, halal, finance, property, lead forms | `references/compliance-my.md` |
| 10 | Competitor research | "Competitor run ads apa" | `references/competitor.md` |
| 11 | Landing page for ads | Before scaling, or CTR good but results low | `references/landing-page.md` |
| 12 | Weekly report | Client or owner summary | `templates/weekly-report.md` |

## Working with data
1. Ask for an Ads Manager export at the level the question needs (ad level for creative, ad set for audiences, with a Day breakdown for anomalies). The column list to tick is in `references/audit.md`.
2. Run `python3 scripts/ads_report.py <file.csv>` (add `--daily` for a day-breakdown export, `--target-cpr 25` for the user's target cost per result in RM). It needs only the Python standard library.
3. Read the script output, then write the answer. Quote the script's numbers exactly. If the columns don't match, show the user which ones are missing.
4. If Python is not available (for example in a chat app), do the same calculations by hand on the pasted table and show the formulas.

## Output shape
- Start with the verdict in 1-2 lines (what is wrong or right, in money terms if possible: "RM420 minggu nie keluar kat 3 ad set yang tak dapat result").
- Then a short table, then 3-5 actions ranked by impact over effort, each naming the exact campaign, ad set or ad.
- End with what to check again and when (e.g. "tengok balik Khamis lepas 3 hari data").

## Upsell to services (only when it fits, at most once)
If the problem is the website or landing page, say Citrus Arc can audit or rebuild it, and stop there.
